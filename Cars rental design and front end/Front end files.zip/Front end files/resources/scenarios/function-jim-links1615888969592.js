(function(window, undefined) {

  var jimLinks = {
    "2cf63dd1-974d-46d4-a705-bb29326271ca" : {
      "Rectangle_4" : [
        "f74f7f7a-c7ea-403b-bd84-a3dd3bddf97b"
      ],
      "Rectangle_7" : [
        "f5fcb3fb-e69e-4ef7-9833-e9a7c191490f"
      ]
    },
    "d9d7fcac-6d4a-4046-9285-8092a15cd813" : {
      "Rectangle_7" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "f2e35772-a737-47dc-8d5b-4cf590cebc8f" : {
      "Rectangle_4" : [
        "f74f7f7a-c7ea-403b-bd84-a3dd3bddf97b"
      ],
      "Rectangle_7" : [
        "f5fcb3fb-e69e-4ef7-9833-e9a7c191490f"
      ]
    },
    "68261dd1-6c1f-4a51-9faa-f74d90530344" : {
      "Rectangle_7" : [
        "f74f7f7a-c7ea-403b-bd84-a3dd3bddf97b"
      ]
    },
    "f74f7f7a-c7ea-403b-bd84-a3dd3bddf97b" : {
      "Rectangle_4" : [
        "f2e35772-a737-47dc-8d5b-4cf590cebc8f"
      ],
      "Rectangle_5" : [
        "f2e35772-a737-47dc-8d5b-4cf590cebc8f"
      ],
      "Rectangle_6" : [
        "2cf63dd1-974d-46d4-a705-bb29326271ca"
      ],
      "Rectangle_7" : [
        "2cf63dd1-974d-46d4-a705-bb29326271ca"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Rectangle_5" : [
        "f74f7f7a-c7ea-403b-bd84-a3dd3bddf97b"
      ]
    },
    "0be0b5ce-6812-4b48-970c-4a7faf46e122" : {
      "Rectangle_4" : [
        "f8a3bbac-a2cd-4dbd-894e-69bda1b24b45"
      ],
      "Rectangle_5" : [
        "f74f7f7a-c7ea-403b-bd84-a3dd3bddf97b"
      ],
      "Rectangle_6" : [
        "fa43d2ed-6d8f-465e-92a8-c6448ed7612d"
      ],
      "Rectangle_10" : [
        "68261dd1-6c1f-4a51-9faa-f74d90530344"
      ],
      "Rectangle_11" : [
        "d9d7fcac-6d4a-4046-9285-8092a15cd813"
      ],
      "Rectangle_12" : [
        "e6c8c498-5df8-405d-91ea-b9f1b263f92a"
      ]
    },
    "fa43d2ed-6d8f-465e-92a8-c6448ed7612d" : {
      "Rectangle_7" : [
        "f74f7f7a-c7ea-403b-bd84-a3dd3bddf97b"
      ]
    },
    "f39803f7-df02-4169-93eb-7547fb8c961a" : {
      "Rectangle_5" : [
        "f74f7f7a-c7ea-403b-bd84-a3dd3bddf97b"
      ],
      "Rectangle_6" : [
        "aa9a7910-2d68-4eb7-a4ec-890f3d5af4eb"
      ],
      "Rectangle_7" : [
        "e414f495-76cd-4a87-9cc6-91712e607de4"
      ],
      "Rectangle_8" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_9" : [
        "f5fcb3fb-e69e-4ef7-9833-e9a7c191490f"
      ],
      "Rectangle_4" : [
        "e1fd79ff-be50-4b33-95aa-0b9ae3b9ea82"
      ],
      "Rectangle_10" : [
        "9902b70e-e902-40e9-a492-0445bc5a6299"
      ],
      "Image_35" : [
        "0be0b5ce-6812-4b48-970c-4a7faf46e122"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);