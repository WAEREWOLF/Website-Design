var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1615888969592.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1615888969592-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      <div id="t-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="208.0px" datasizeheight="175.0px" dataX="0.0" dataY="15.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/08d9c2cf-adef-47b3-acf7-1b51c308cf58.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="t-Group_2" class="group firer ie-background commentable non-processed" customid="Group_2" datasizewidth="631.0px" datasizeheight="43.0px" >\
        <div id="t-Rectangle_5" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_5"   datasizewidth="160.0px" datasizeheight="43.0px" datasizewidthpx="160.0" datasizeheightpx="43.0" dataX="369.0" dataY="81.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-t-Rectangle_5_0">Cars</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="t-Rectangle_6" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_6"   datasizewidth="160.0px" datasizeheight="43.0px" datasizewidthpx="160.0" datasizeheightpx="43.0" dataX="546.0" dataY="81.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-t-Rectangle_6_0">Contact</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="t-Rectangle_7" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_7"   datasizewidth="160.0px" datasizeheight="43.0px" datasizewidthpx="160.0" datasizeheightpx="43.0" dataX="725.0" dataY="81.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-t-Rectangle_7_0">About</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="t-Rectangle_8" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_8"   datasizewidth="160.0px" datasizeheight="43.0px" datasizewidthpx="160.0" datasizeheightpx="43.0" dataX="192.0" dataY="81.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-t-Rectangle_8_0">Home</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="t-Rectangle_9" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_7"   datasizewidth="160.0px" datasizeheight="43.0px" datasizewidthpx="160.0" datasizeheightpx="43.0" dataX="901.0" dataY="81.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-t-Rectangle_9_0">My Cars</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="t-Rectangle_4" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_4"   datasizewidth="90.0px" datasizeheight="48.0px" datasizewidthpx="89.99999999999977" datasizeheightpx="48.0" dataX="1080.0" dataY="81.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-t-Rectangle_4_0">Register </span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="t-Rectangle_10" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_4"   datasizewidth="90.0px" datasizeheight="48.0px" datasizewidthpx="90.0" datasizeheightpx="48.0" dataX="1181.0" dataY="81.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-t-Rectangle_10_0">Login</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="t-Image_35" class="pie image firer click ie-background commentable non-processed" customid="Image_35"   datasizewidth="50.0px" datasizeheight="59.0px" dataX="1203.0" dataY="15.0"   alt="image" systemName="./images/d9234de4-72a5-4595-8521-400bc0bf060a.svg" overlay="#CBCBCB">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 17 20" width="17px">\
          	    <!-- Generator: Sketch 52.1 (67048) - http://www.bohemiancoding.com/sketch -->\
          	    <title>user</title>\
          	    <desc>Created with Sketch.</desc>\
          	    <g fill="none" fill-rule="evenodd" id="t-Image_35-Page-1" stroke="none" stroke-width="1">\
          	        <g fill="#666666" id="t-Image_35-user">\
          	            <path d="M8.63492063,0 C5.80790159,0 3.50793651,2.29996508 3.50793651,5.12698413 C3.50793651,7.95400317 5.80790159,10.2539683 8.63492063,10.2539683 C11.4619397,10.2539683 13.7619048,7.95400317 13.7619048,5.12698413 C13.7619048,2.29996508 11.4619397,0 8.63492063,0" id="t-Image_35-Fill-1" style="fill:#CBCBCB !important;" />\
          	            <path d="M9.63332578,11.4682653 L7.36665911,11.4682653 C5.40191244,11.4682653 3.55087689,12.2442836 2.15461022,13.65341 C0.765181333,15.0556274 -7.55555556e-06,16.9065514 -7.55555556e-06,18.8653527 C-7.55555556e-06,19.1764059 0.253708,19.4285827 0.566659111,19.4285827 L16.4333258,19.4285827 C16.7462769,19.4285827 16.9999924,19.1764059 16.9999924,18.8653527 C16.9999924,16.9065514 16.2348036,15.0556274 14.8453747,13.65341 C13.449108,12.2442836 11.5981102,11.4682653 9.63332578,11.4682653 Z" id="t-Image_35-Fill-3" style="fill:#CBCBCB !important;" />\
          	        </g>\
          	    </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="t-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="35.3px" datasizeheight="13.0px" dataX="1208.3" dataY="61.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-t-Paragraph_1_0">CLICK</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-t-Line_1" customid="Line" class="shapewrapper shapewrapper-t-Line_1 non-processed"   datasizewidth="20.5px" datasizeheight="12.0px" datasizewidthpx="20.49999999999961" datasizeheightpx="12.0" dataX="1215.8" dataY="39.0" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-t-Line_1" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="t-Line_1" class="pie line shape non-processed-shape eMarker firer ie-background commentable non-processed" customid="Line" d="M 0.0 5.0 L 18.49999999999961 5.0"  marker-end="url(#end-marker-t-Line_1">\
                      </path>\
                  </g>\
              </g>\
              <defs>\
      			<marker id="end-marker-t-Line_1" class="open endmarker" orient="0" stroke-width="0px" viewBox="0 0 100 100" refY="50" preserveAspectRatio="none" markerUnits="userSpaceOnUse">\
      				<path d="M 39.688716 40.466926 39.818418 60.051881 7.9118028 79.24773 C -6.6058565 88.636494 5.3977603 106.07944 19.844358 97.146562 L 99.610893 50.324254 21.53048 3.7613489 C 4.631474 -8.1505951 -6.7257532 14.353316 7.6523994 20.881971 Z"></path>\
      			</marker>\
              </defs>\
          </svg>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-e414f495-76cd-4a87-9cc6-91712e607de4" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="About" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/e414f495-76cd-4a87-9cc6-91712e607de4-1615888969592.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/e414f495-76cd-4a87-9cc6-91712e607de4-1615888969592-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/e414f495-76cd-4a87-9cc6-91712e607de4-1615888969592-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Paragraph_2" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph_2"   datasizewidth="485.0px" datasizeheight="90.0px" dataX="612.0" dataY="172.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">About</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_1" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph_1"   datasizewidth="603.0px" datasizeheight="240.0px" dataX="104.0" dataY="306.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">We are Car Era, a car showroom where clients can also reserve the car they want in our showroom.<br /><br />Car Era Head Quarters is in Craiova, Romania since 1985, improving the services each day, in order to meet the client expectations.<br /><br /><br /><br /></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_4" class="pie image firer ie-background commentable non-processed" customid="Image"   datasizewidth="375.0px" datasizeheight="291.0px" dataX="158.0" dataY="487.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/e79a4879-04df-4119-b644-a3363861de00.jpg" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image"   datasizewidth="479.0px" datasizeheight="418.0px" dataX="760.0" dataY="278.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/b4aa01ac-3053-4b0c-922f-ba8f3e2fa386.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;